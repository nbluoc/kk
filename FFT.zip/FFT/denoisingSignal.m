function [ denoisedMatrixA1 ] = denoisingSignal( matrixA1 )
%% denoising procedure
tic;
lev = 5;
wname = 'sym8';
denoisedMatrixA1 = zeros(size(matrixA1));
t = 1:size(matrixA1,2);
for i=1:size(matrixA1,1)
    sig = matrixA1(i,:);
    dnsig1 = wden(sig,'minimaxi','h','mln',lev,wname);
    denoisedMatrixA1(i,:) = dnsig1;
end
toc;
% figure,hold on,
% plot(t,dnsig1)
% plot(t,sig,'r')
% title('Denoised Signal - SURE')
% hold off;
end

