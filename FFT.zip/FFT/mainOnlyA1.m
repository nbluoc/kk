clc;
close all;
% clear all;

%% Load Condition A1
[tableA11,tableA12,tableA13,tableA14] = loadConditionA1();
matrixA1 = [tableA11,tableA12,tableA13,tableA14];   % size(matrixA1)
matrixA1 = matrixA1'; %.*10^(-3); %10x500000

% figure,plot(ad1_13*10)
% from time to frequence domain
[ frequencyMatrixA1 ] = FourierTransform( matrixA1 );
% Study on frequencies
[ deltaA1,thetaA1,alphaA1,betaA1,gammaA1,highgammaA1] = FrequencyStudy( matrixA1,frequencyMatrixA1 );

% [ denoisedMatrixA1 ] = denoisingSignal( matrixA1 );
% % from time to frequence domain
% [ frequencyMatrixA1,DenoisedFrequencyMatrixA1 ] = FourierTransform( matrixA1,denoisedMatrixA1 );
% % Study on frequencies
% [ deltaA1,betaA1,gammaA1,alphaA1 ] = FrequencyStudy( matrixA1,frequencyMatrixA1 );


%% test
%
Fs = 100000;            % Sampling frequency                    
% T = 1/Fs;            % Sampling period       
L = size(matrixA1,2);% Length of signal
% t = (0:L-1)*T;       % Time vector
f = (0:L/2-1)*Fs/L; 

%f1 = figure;
%for i=1:40
%subplot(6,5,i)
%plot(f(2:500),log10(frequencyMatrixA1(i,2:500)),'-k','Linewidth',2)

%xlabel('Frequency (Hz)','Fontsize',18)
%ylabel('Power Spectrum','Fontsize',18)
%title('First 100 Hz of A1 Condition (mean)','Fontsize',18)
%set(gca,'Fontsize',16)
%axis([0 100 -15 0])
%end
%ax = findobj(f1,'Type','Axes');
%for i=1:length(ax)
    %xlabel(ax(i),{'Hz'})
    %ylabel(ax(i),{'log_1_0(PowerSpectrum)'})
    %title(ax(i),{['A',num2str(i)]})
%end

%% Count Rates

ratesA1 = countRates(frequencyMatrixA1,matrixA1);


x4 = ratesA1;
figure;
bar(x4)
% xlabel('delta','alpha','beta','gamma','Fontsize',18)
ylabel('mean of rates A1','Fontsize',18)
title('Mean of rates','Fontsize',18)

% means = [ratesA1;ratesA2;ratesA3;ratesB1;ratesB2;ratesB3];

% 
% figure;
% for i=1:50
% subplot(5,10,i)
% plot(f(2:1000),(frequencyMatrixA1(i,2:1000)),'-k','Linewidth',2)
% 
% xlabel('Frequency (Hz)','Fontsize',10)
% ylabel('Power Spectrum','Fontsize',10)
% % title('First 100 Hz of A1 Condition ','Fontsize',12)
% set(gca,'Fontsize',12)
% saveas(gcf,'?3.jpg')
% end

% %% spectrogram https://www.mathworks.com/help/signal/ref/spectrogram.html
% figure;
% % spectrogram(f(2:500),mean(frequencyMatrixA1(:,2:500)),window,nfft)  % uses nfft sampling points to calculate the discrete Fourier transform.
% spectrogram(f(2:500),mean(frequencyMatrixA1(:,2:500)),'yaxis')
% title('Spectrogram A1 Condition (mean)','Fontsize',18)

%% edw pairnw to mean tou kathe condition
figure;
plot(f(2:1000),mean(frequencyMatrixA1(:,2:1000)),'-k','Linewidth',2)
% plot(f(2:1000),log10 (frequencyMatrixA1(i,2:1000)),'-k','Linewidth',2)
xlabel('Frequency (Hz)','Fontsize',18)
ylabel('Power Spectrum','Fontsize',18)
title('First 100 Hz of A1 Condition (mean)','Fontsize',18)
axis([0 180 0 6*10^(-2)])

figure;
plot(f(2:1000),mean(frequencyMatrixA1(:,2:1000)),'-k','Linewidth',2)
set(gca, 'YScale', 'log')
xlabel('Frequency (Hz)','Fontsize',18)
ylabel('Power Spectrum','Fontsize',18)
title('First 100 Hz of A1 Condition (mean)','Fontsize',18)
axis([0 180 0 10^(6)])

% mean values/rates of power spectrum

meanA1 = mean(ratesA1,1);

x1 = meanA1;
figure;
bar(x1)
% xlabel('delta','alpha','beta','gamma','Fontsize',18)
ylabel('mean of rates A1','Fontsize',18)
title('Mean of rates','Fontsize',18)
% axis ([0 4.5 0 40])


%KATEFTHEIAN STO EXCEL
filename = 'meanA1.dat';
A = meanA1;
delimiter = ',';
dlmwrite(filename,A,delimiter)
% xlswrite('cells.xlsx',num_cells(i));
disp (A)