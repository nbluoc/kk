function [ frequencyMatrixA1 ] = FourierTransform( matrixA1 )

Fs = 100000;            % Sampling frequency                    
% T = 1/Fs;            % Sampling period       
L = size(matrixA1,2);% Length of signal
% t = (0:L-1)*T;       % Time vector
% f = [1:1:L]*Fs/L-Fs/2;
f = (0:L/2-1)*Fs/L; 
frequencyMatrixA1 = zeros(size(matrixA1,1),length(f));
for i=1:size(matrixA1,1)
    S = matrixA1(i,:);
    Y = fft(S);
% % %     P2 = Y(1:L/2);
% % %     P1 = (1/(Fs*L)) * abs(P2).^2;
    P2 = abs(Y/L);%normalization with length of signal 500000
    P2 = P2(1:L/2);
%     P1 = 2*P2;
    P1 = P2.^2;
%     if sum(P1) > 1
%         TIGINETAI = 1111111111111
%     end
    frequencyMatrixA1(i,:) = P1;
end
% % % % apotelesma = sum(P1)
% % % % FFT to denoised data
% % % DenoisedFrequencyMatrixA1 = zeros(size(matrixA1,1),length(f));
% % % for i=1:size(matrixA1,1)
% % %     S = denoisedMatrixA1(i,:);
% % %     Y = fft(S);
% % %     P2 = abs(Y/L);
% % %     P2 = P2(1:L/2);
% % %     P1 = P2.^2;
% % %     DenoisedFrequencyMatrixA1(i,:) = P1;
% % % end
% plot(f,P1,'r') 
% hold off;
% title('Single-Sided Amplitude Spectrum Comparison between two timeseries','FontSize', 30) 
% xlabel('f (Hz)','FontSize', 30) 
% ylabel('|P1(f)|','FontSize', 30) 
% legend('Original','Denoised')
% set(gca,'fontsize',20)
end

