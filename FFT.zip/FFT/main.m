clc;
close all;
% clear all;

%% Load Condition A1
[tableA11,tableA12,tableA13,tableA14] = loadConditionA1();
matrixA1 = [tableA11,tableA12,tableA13,tableA14];   % size(matrixA1)
matrixA1 = matrixA1';%.*10^(-3); %10x500000

% figure,plot(ad1_13*10)
% from time to frequence domain
[ frequencyMatrixA1 ] = FourierTransform( matrixA1 );
% Study on frequencies
[ deltaA1,alphaA1,betaA1,gammaA1] = FrequencyStudy( matrixA1,frequencyMatrixA1 );

% [ denoisedMatrixA1 ] = denoisingSignal( matrixA1 );
% % from time to frequence domain
% [ frequencyMatrixA1,DenoisedFrequencyMatrixA1 ] = FourierTransform( matrixA1,denoisedMatrixA1 );
% % Study on frequencies
% [ deltaA1,betaA1,gammaA1,alphaA1 ] = FrequencyStudy( matrixA1,frequencyMatrixA1 );

%% Load Condition A2
[tableA21,tableA22,tableA23,tableA24] = loadConditionA2();
matrixA2 = [tableA21,tableA22,tableA23,tableA24];
matrixA2 = matrixA2';%.*10^(-3);

% figure,plot(ad1_206*10)
% [ denoisedMatrixA2 ] = denoisingSignal( matrixA2 );
% from time to frequence domain
[ frequencyMatrixA2 ] = FourierTransform( matrixA2 );
% Study on frequencies
[ deltaA2,alphaA2,betaA2,gammaA2 ] = FrequencyStudy( matrixA2,frequencyMatrixA2 );


% [ denoisedMatrixA2 ] = denoisingSignal( matrixA2 );
% % from time to frequence domain
% [ frequencyMatrixA2,DenoisedFrequencyMatrixA2 ] = FourierTransform( matrixA2,denoisedMatrixA2 );
% % Study on frequencies
% [ deltaA2,betaA2,gammaA2,alphaA2 ] = FrequencyStudy( matrixA2,frequencyMatrixA2 );

%% Load Condition A3
[tableA31,tableA32,tableA33,tableA34] = loadConditionA3();
matrixA3 = [tableA31,tableA32,tableA33,tableA34];
matrixA3 = matrixA3';%.*10^(-3);

% from time to frequence domain
[ frequencyMatrixA3 ] = FourierTransform( matrixA3 );
% Study on frequencies
[ deltaA3,alphaA3,betaA3,gammaA3] = FrequencyStudy( matrixA3,frequencyMatrixA3 );

% [ denoisedMatrixA3 ] = denoisingSignal( matrixA3 );
% % from time to frequence domain
% [ frequencyMatrixA3,DenoisedFrequencyMatrixA3 ] = FourierTransform( matrixA3,denoisedMatrixA3 );
% % Study on frequencies
% [ deltaA3,betaA3,gammaA3,alphaA3 ] = FrequencyStudy( matrixA3,frequencyMatrixA3 );

%% Load Condition B1
[tableB11,tableB12,tableB13,tableB14,tableB15] = loadConditionB1();
matrixB1 = [tableB11,tableB12,tableB13,tableB14,tableB15];
matrixB1 = matrixB1';%.*10^(-3);

% from time to frequence domain
[ frequencyMatrixB1 ] = FourierTransform( matrixB1 );
% Study on frequencies
[ deltaB1,alphaB1,betaB1,gammaB1] = FrequencyStudy( matrixB1,frequencyMatrixB1 );


% [ denoisedMatrixB1 ] = denoisingSignal( matrixB1 );
% % from time to frequence domain
% [ frequencyMatrixB1,DenoisedFrequencyMatrixB1 ] = FourierTransform( matrixB1,denoisedMatrixB1 );
% % Study on frequencies
% [ deltaB1,betaB1,gammaB1,alphaB1 ] = FrequencyStudy( matrixB1,frequencyMatrixB1 );
%% Load Condition B2
[tableB21,tableB22,tableB23,tableB24,tableB25] = loadConditionB2();
matrixB2 = [tableB21,tableB22,tableB23,tableB24,tableB25];
matrixB2 = matrixB2';%.*10^(-3);

% from time to frequence domain
[ frequencyMatrixB2 ] = FourierTransform( matrixB2 );
% Study on frequencies
[ deltaB2,alphaB2,betaB2,gammaB2] = FrequencyStudy( matrixB2,frequencyMatrixB2 );


% [ denoisedMatrixB2 ] = denoisingSignal( matrixB2 );
% % from time to frequence domain
% [ frequencyMatrixB2,DenoisedFrequencyMatrixB2 ] = FourierTransform( matrixB2,denoisedMatrixB2 );
% % Study on frequencies
% [ deltaB2,betaB2,gammaB2,alphaB2 ] = FrequencyStudy( matrixB2,frequencyMatrixB2 );
%% Load Condition B3
[tableB31,tableB32,tableB33,tableB34,tableB35] = loadConditionB3();
matrixB3 = [tableB31,tableB32,tableB33,tableB34,tableB35];
matrixB3 = matrixB3';%.*10^(-3);

% from time to frequence domain
[ frequencyMatrixB3 ] = FourierTransform( matrixB3 );
% Study on frequencies
[ deltaB3,alphaB3, betaB3,gammaB3] = FrequencyStudy( matrixB3,frequencyMatrixB3 );

% [ denoisedMatrixB3 ] = denoisingSignal( matrixB3 );
% % from time to frequence domain
% [ frequencyMatrixB3,DenoisedFrequencyMatrixB3 ] = FourierTransform( matrixB3,denoisedMatrixB3 );
% % Study on frequencies
% [ deltaB3,betaB3,gammaB3,alphaB3 ] = FrequencyStudy( matrixB3,frequencyMatrixB3 );

%% test
%
Fs = 100000;            % Sampling frequency                    
% T = 1/Fs;            % Sampling period       
L = size(matrixA1,2);% Length of signal
% t = (0:L-1)*T;       % Time vector
f = (0:L/2-1)*Fs/L; 

%f1 = figure;
%for i=1:10
%subplot(2,5,i)
%plot(f(2:500),log10(frequencyMatrixA1(i,2:500)),'-k','Linewidth',2)

%xlabel('Frequency (Hz)','Fontsize',18)
%ylabel('Power Spectrum','Fontsize',18)
%title('First 100 Hz of A1 Condition (mean)','Fontsize',18)
%set(gca,'Fontsize',16)
%axis([0 100 -15 0])
%end
%ax = findobj(f1,'Type','Axes');
%for i=1:length(ax)
    %xlabel(ax(i),{'Hz'})
    %ylabel(ax(i),{'log_1_0(PowerSpectrum)'})
    %title(ax(i),{['A',num2str(i)]})
%end

%f2 = figure;
%for i=1:10
%subplot(2,5,i)
%plot(f(2:500),log10(frequencyMatrixB1(i,2:500)),'-k','Linewidth',2)

%xlabel('Frequency (Hz)','Fontsize',18)
%ylabel('Power Spectrum','Fontsize',18)
%title('First 100 Hz of B1 Condition (mean)','Fontsize',18)
%set(gca,'Fontsize',16)
%axis([0 100 -15 0])
%end
%ax = findobj(f2,'Type','Axes');
%for i=1:length(ax)
   % xlabel(ax(i),{'Hz'})
   % ylabel(ax(i),{'log_1_0(PowerSpectrum)'})
    %title(ax(i),{['B',num2str(i)]})
%end

%% Count Rates

ratesA1 = countRates(frequencyMatrixA1,matrixA1);
ratesA2 = countRates(frequencyMatrixA2,matrixA2);
ratesA3 = countRates(frequencyMatrixA3,matrixA3);
ratesB1 = countRates(frequencyMatrixB1,matrixB1);
ratesB2 = countRates(frequencyMatrixB2,matrixB2);
ratesB3 = countRates(frequencyMatrixB3,matrixB3);

% x4 = ratesB1;
% figure;
% bar(x4)
% % xlabel('delta','alpha','beta','gamma','Fontsize',18)
% ylabel('mean of rates B1','Fontsize',18)
% title('Mean of rates','Fontsize',18)

% means = [ratesA1;ratesA2;ratesA3;ratesB1;ratesB2;ratesB3];
%% compute features

%[ratesA1,matrixFeatureA1] = countRates(frequencyMatrixA1,matrixA1);
%[ratesA2,matrixFeatureA2] = countRates(frequencyMatrixA2,matrixA2);
%[ratesA3,matrixFeatureA3] = countRates(frequencyMatrixA3,matrixA3);
%[ratesB1,matrixFeatureB1] = countRates(frequencyMatrixB1,matrixB1);
%[ratesB2,matrixFeatureB2] = countRates(frequencyMatrixB2,matrixB2);
%[ratesB3,matrixFeatureB3] = countRates(frequencyMatrixB3,matrixB3);
% 
% 
% %% classification
% tic;
% [accuracy,bestCluster,centroids] = classificationNew(matrixFeatureA1,matrixFeatureA2,matrixFeatureA3,matrixFeatureB1,matrixFeatureB2,matrixFeatureB3);
% toc;

% %%
% pinakas = [mean(accuracy),median(accuracy),std(accuracy),max(accuracy),min(accuracy)]
% 
% [value,pos] = max(accuracy)
% new_accuracy = reshape(accuracy,12,10);
% new_accuracy = new_accuracy';

% %% edw kanw figure to kathe condition 
% 
f3 = figure;
for i=1:10
subplot(2,5,i)
plot(f(2:1000),(frequencyMatrixA1(i,2:1000)),'-k','Linewidth',2)

xlabel('Frequency (Hz)','Fontsize',18)
ylabel('Power Spectrum','Fontsize',18)
title('First 100 Hz of A1 Condition ','Fontsize',18)
set(gca,'Fontsize',16)
saveas(gcf,'?3.jpg')
end
% 
% f4 = figure;
% for i=1:10
% subplot(2,5,i)
% plot(f(2:1000),(frequencyMatrixB1(i,2:1000)),'-k','Linewidth',2)
% 
% xlabel('Frequency (Hz)','Fontsize',18)
% ylabel('Power Spectrum','Fontsize',18)
% title('First 100 Hz of B1 Condition ','Fontsize',18)
% set(gca,'Fontsize',16)
% 
% end
% 
% f5 = figure;
% for i=1:10
% subplot(2,5,i)
% plot(f(2:1000),(frequencyMatrixA2(i,2:1000)),'-k','Linewidth',2)
% 
% xlabel('Frequency (Hz)','Fontsize',18)
% ylabel('Power Spectrum','Fontsize',18)
% title('First 100 Hz of A2 Condition ','Fontsize',18)
% set(gca,'Fontsize',16)
% saveas(gcf,'?3.jpg')
% end
% 
% f6 = figure;
% for i=1:10
% subplot(2,5,i)
% plot(f(2:1000),(frequencyMatrixB2(i,2:1000)),'-k','Linewidth',2)
% 
% xlabel('Frequency (Hz)','Fontsize',18)
% ylabel('Power Spectrum','Fontsize',18)
% title('First 100 Hz of B2 Condition ','Fontsize',18)
% set(gca,'Fontsize',16)
% saveas(gcf,'?3.jpg')
% end
% 
% f7 = figure;
% for i=1:10
% subplot(2,5,i)
% plot(f(2:1000),(frequencyMatrixA3(i,2:1000)),'-k','Linewidth',2)
% 
% xlabel('Frequency (Hz)','Fontsize',18)
% ylabel('Power Spectrum','Fontsize',18)
% title('First 100 Hz of A3 Condition ','Fontsize',18)
% set(gca,'Fontsize',16)
% saveas(gcf,'?3.jpg')
% end
% 
% f8 = figure;
% for i=1:10
% subplot(2,5,i)
% plot(f(2:1000),(frequencyMatrixB3(i,2:1000)),'-k','Linewidth',2)
% 
% xlabel('Frequency (Hz)','Fontsize',18)
% ylabel('Power Spectrum','Fontsize',18)
% title('First 100 Hz of B3 Condition ','Fontsize',18)
% set(gca,'Fontsize',16)
% saveas(gcf,'?3.jpg')
% end
% 
% set(0,'DefaultFigureVisible','on');

% %% spectrogram https://www.mathworks.com/help/signal/ref/spectrogram.html
% figure;
% % spectrogram(f(2:500),mean(frequencyMatrixA1(:,2:500)),window,nfft)  % uses nfft sampling points to calculate the discrete Fourier transform.
% spectrogram(f(2:500),mean(frequencyMatrixA1(:,2:500)),'yaxis')
% title('Spectrogram A1 Condition (mean)','Fontsize',18)
% figure;
% spectrogram(f(2:500),mean(frequencyMatrixA2(:,2:500)),'yaxis')
% title('Spectrogram A2 Condition (mean)','Fontsize',18)
% 
% % figure;
% % pwelch ( f(2:500), mean(frequencyMatrixA2(:,2:500)), 'hamming' );
% % title('Spectrogram A2 Condition (mean)des edo','Fontsize',18)
% % figure;
% % spectrum ( f(2:500), mean(frequencyMatrixA2(:,2:500)), 'hamming' );
% 
% figure;
% spectrogram(f(2:500),mean(frequencyMatrixA3(:,2:500)),'yaxis')
% title('Spectrogram A3 Condition (mean)','Fontsize',18)
% figure;
% spectrogram(f(2:500),mean(frequencyMatrixB1(:,2:500)),'yaxis')
% title('Spectrogram B1 Condition (mean)','Fontsize',18)
% figure;
% spectrogram(f(2:500),mean(frequencyMatrixB2(:,2:500)),'yaxis')
% title('Spectrogram B2 Condition (mean)','Fontsize',18)
% figure;
% spectrogram(f(2:500),mean(frequencyMatrixB3(:,2:500)),'yaxis')
% title('Spectrogram B3 Condition (mean)','Fontsize',18)

%% edw pairnw to mean tou kathe condition
f9 = figure;
plot(f(2:500),mean(frequencyMatrixA1(:,2:500)),'-k','Linewidth',2)
xlabel('Frequency (Hz)','Fontsize',18)
ylabel('Power Spectrum','Fontsize',18)
title('First 100 Hz of A1 Condition (mean)','Fontsize',18)
axis([0 100 0 5*10^(-4)])

f10 = figure;
plot(f(2:500),mean(frequencyMatrixA2(:,2:500)),'-k','Linewidth',2)
xlabel('Frequency (Hz)','Fontsize',18)
ylabel('Power Spectrum','Fontsize',18)
title('First 100 Hz of A2 Condition (mean)','Fontsize',18)
axis([0 100 0 5*10^(-4)])

f11 = figure;
plot(f(2:500),mean(frequencyMatrixA3(:,2:500)),'-k','Linewidth',2)
xlabel('Frequency (Hz)','Fontsize',18)
ylabel('Power Spectrum','Fontsize',18)
title('First 100 Hz of A3 Condition (mean)','Fontsize',18)
axis([0 100 0 5*10^(-4)])

f12 = figure;
plot(f(2:500),mean(frequencyMatrixB1(:,2:500)),'-k','Linewidth',2)
xlabel('Frequency (Hz)','Fontsize',18)
ylabel('Power Spectrum','Fontsize',18)
title('First 100 Hz of B1 Condition (mean)','Fontsize',18)
axis([0 100 0 2*10^(-2)])

f13 = figure;
plot(f(2:500),mean(frequencyMatrixB2(:,2:500)),'-k','Linewidth',2)
xlabel('Frequency (Hz)','Fontsize',18)
ylabel('Power Spectrum','Fontsize',18)
title('First 100 Hz of B2 Condition (mean)','Fontsize',18)
axis([0 100 0 2*10^(-2)])

f14 = figure;
plot(f(2:500),mean(frequencyMatrixB3(:,2:500)),'-k','Linewidth',2)
xlabel('Frequency (Hz)','Fontsize',18)
ylabel('Power Spectrum','Fontsize',18)
title('First 100 Hz of B3 Condition (mean)','Fontsize',18)
axis([0 100 0 2*10^(-2)])

% mean values/rates of power spectrum

meanA1 = mean(ratesA1,1);
meanA2 = mean(ratesA2,1);
meanA3 = mean(ratesA3,1);
meanB1 = mean(ratesB1,1);
meanB2 = mean(ratesB2,1);
meanB3 = mean(ratesB3,1);

means = [meanA1;meanA2;meanA3;meanB1;meanB2;meanB3]; %[meanA1;meanA2;meanA3]; %;meanB1;meanB2;meanB3];
x0 = means;
figure;
bar(x0)
% xlabel('delta','alpha','beta','gamma','Fontsize',18)
ylabel('means ','Fontsize',18)
title('Mean of all rates','Fontsize',18)
axis ([0 4.5 0 40])


% rates = [delta',alpha',beta',gamma'];
x1 = meanA1;
figure;
bar(x1)
% xlabel('delta','alpha','beta','gamma','Fontsize',18)
ylabel('mean of rates A1','Fontsize',18)
title('Mean of rates','Fontsize',18)

x2 = meanA2;
figure;
bar(x2)
% xlabel('delta','alpha','beta','gamma','Fontsize',18)
ylabel('mean of rates A2','Fontsize',18)
title('Mean of rates','Fontsize',18)

x3 = meanA3;
figure;
bar(x3)
% xlabel('delta','alpha','beta','gamma','Fontsize',18)
ylabel('mean of rates A3','Fontsize',18)
title('Mean of rates','Fontsize',18)

x4 = meanB1;
figure;
bar(x4)
% xlabel('delta','alpha','beta','gamma','Fontsize',18)
ylabel('mean of rates B1','Fontsize',18)
title('Mean of rates','Fontsize',18)

x5 = meanB2;
figure;
bar(x5)
% xlabel('delta','alpha','beta','gamma','Fontsize',18)
ylabel('mean of rates B2','Fontsize',18)
title('Mean of rates','Fontsize',18)

x6 = meanB3;
figure;
bar(x6)
% xlabel('delta','alpha','beta','gamma','Fontsize',18)
ylabel('mean of rates B3','Fontsize',18)
title('Mean of rates','Fontsize',18)

% x7 = means;
% figure;
% bar(x7)
% % xlabel('delta','alpha','beta','gamma','Fontsize',18)
% ylabel('mean of rates','Fontsize',18)
% title('Means of rates','Fontsize',18)
%% edw kanw figure to kathe condition 
% f1 = figure;
% for i=1:10
% subplot(2,5,i)
% plot(f(2:500),(frequencyMatrixA1(i,2:500)),'-k','Linewidth',2)
% 
% xlabel('Frequency (Hz)','Fontsize',18)
% ylabel('Power Spectrum','Fontsize',18)
% title('First 100 Hz of A1 Condition','Fontsize',18)
% set(gca,'Fontsize',8)
% axis([0 100 0 5*10^(-4)])
% end
% 
% ax = findobj(f1,'Type','Axes');
% for i=1:length(ax)
%     xlabel(ax(i),{'Hz'})
%     ylabel(ax(i),{'PowerSpectrum'})
%     title(ax(i),{['Condition A1 ',num2str(i)]})
% end
% 
% f2 = figure;
% for i=1:10
% subplot(2,5,i)
% plot(f(2:500),(frequencyMatrixB1(i,2:500)),'-k','Linewidth',2)
% 
% xlabel('Frequency (Hz)','Fontsize',18)
% ylabel('Power Spectrum','Fontsize',18)
% title('First 100 Hz of B1 Condition','Fontsize',18)
% set(gca,'Fontsize',8)
% axis([0 100 0 2*10^(-2)])
% end
% ax = findobj(f2,'Type','Axes');
% for i=1:length(ax)
%     xlabel(ax(i),{'Hz'})
%     ylabel(ax(i),{'Power Spectrum'})
%     title(ax(i),{['Condition B1 ',num2str(i)]})
% end
%% 

%allRates = [ratesA1;ratesA2;ratesA3;ratesB1;ratesB2;ratesB3];