clc;
close all;
% clear all;

% %% Load Condition A1
% [tableA11,tableA12,tableA13,tableA14] = loadConditionA1();
% matrixA1 = [tableA11,tableA12,tableA13,tableA14];   % size(matrixA1)
% matrixA1 = matrixA1';%.*10^(-3); %10x500000
% 
% % figure,plot(ad1_13*10)
% % from time to frequence domain
% [ frequencyMatrixA1 ] = FourierTransform( matrixA1 );
% % Study on frequencies
% [ deltaA1,alphaA1,betaA1,gammaA1] = FrequencyStudy( matrixA1,frequencyMatrixA1 );
% 
% % [ denoisedMatrixA1 ] = denoisingSignal( matrixA1 );
% % % from time to frequence domain
% % [ frequencyMatrixA1,DenoisedFrequencyMatrixA1 ] = FourierTransform( matrixA1,denoisedMatrixA1 );
% % % Study on frequencies
% % [ deltaA1,betaA1,gammaA1,alphaA1 ] = FrequencyStudy( matrixA1,frequencyMatrixA1 );
% 
% %% Load Condition A2
% [tableA21,tableA22,tableA23,tableA24] = loadConditionA2();
% matrixA2 = [tableA21,tableA22,tableA23,tableA24];
% matrixA2 = matrixA2';%.*10^(-3);
% 
% % figure,plot(ad1_206*10)
% % [ denoisedMatrixA2 ] = denoisingSignal( matrixA2 );
% % from time to frequence domain
% [ frequencyMatrixA2 ] = FourierTransform( matrixA2 );
% % Study on frequencies
% [ deltaA2,alphaA2,betaA2,gammaA2 ] = FrequencyStudy( matrixA2,frequencyMatrixA2 );
% 
% 
% % [ denoisedMatrixA2 ] = denoisingSignal( matrixA2 );
% % % from time to frequence domain
% % [ frequencyMatrixA2,DenoisedFrequencyMatrixA2 ] = FourierTransform( matrixA2,denoisedMatrixA2 );
% % % Study on frequencies
% % [ deltaA2,betaA2,gammaA2,alphaA2 ] = FrequencyStudy( matrixA2,frequencyMatrixA2 );
% 
% %% Load Condition A3
% [tableA31,tableA32,tableA33,tableA34] = loadConditionA3();
% matrixA3 = [tableA31,tableA32,tableA33,tableA34];
% matrixA3 = matrixA3';%.*10^(-3);
% 
% % from time to frequence domain
% [ frequencyMatrixA3 ] = FourierTransform( matrixA3 );
% % Study on frequencies
% [ deltaA3,alphaA3,betaA3,gammaA3] = FrequencyStudy( matrixA3,frequencyMatrixA3 );
% 
% % [ denoisedMatrixA3 ] = denoisingSignal( matrixA3 );
% % % from time to frequence domain
% % [ frequencyMatrixA3,DenoisedFrequencyMatrixA3 ] = FourierTransform( matrixA3,denoisedMatrixA3 );
% % % Study on frequencies
% % [ deltaA3,betaA3,gammaA3,alphaA3 ] = FrequencyStudy( matrixA3,frequencyMatrixA3 );

%% Load Condition B1
[tableB11,tableB12,tableB13,tableB14,tableB15] = loadConditionB1();
matrixB1 = [tableB11,tableB12,tableB13,tableB14,tableB15];
matrixB1 = matrixB1';%.*10^(-3);

% from time to frequence domain
[ frequencyMatrixB1 ] = FourierTransform( matrixB1 );
% Study on frequencies
[ deltaB1,alphaB1,betaB1,gammaB1] = FrequencyStudy( matrixB1,frequencyMatrixB1 );


% [ denoisedMatrixB1 ] = denoisingSignal( matrixB1 );
% % from time to frequence domain
% [ frequencyMatrixB1,DenoisedFrequencyMatrixB1 ] = FourierTransform( matrixB1,denoisedMatrixB1 );
% % Study on frequencies
% [ deltaB1,betaB1,gammaB1,alphaB1 ] = FrequencyStudy( matrixB1,frequencyMatrixB1 );
%% Load Condition B2
[tableB21,tableB22,tableB23,tableB24,tableB25] = loadConditionB2();
matrixB2 = [tableB21,tableB22,tableB23,tableB24,tableB25];
matrixB2 = matrixB2';%.*10^(-3);

% from time to frequence domain
[ frequencyMatrixB2 ] = FourierTransform( matrixB2 );
% Study on frequencies
[ deltaB2,alphaB2,betaB2,gammaB2] = FrequencyStudy( matrixB2,frequencyMatrixB2 );


% [ denoisedMatrixB2 ] = denoisingSignal( matrixB2 );
% % from time to frequence domain
% [ frequencyMatrixB2,DenoisedFrequencyMatrixB2 ] = FourierTransform( matrixB2,denoisedMatrixB2 );
% % Study on frequencies
% [ deltaB2,betaB2,gammaB2,alphaB2 ] = FrequencyStudy( matrixB2,frequencyMatrixB2 );
%% Load Condition B3
[tableB31,tableB32,tableB33,tableB34,tableB35] = loadConditionB3();
matrixB3 = [tableB31,tableB32,tableB33,tableB34,tableB35];
matrixB3 = matrixB3';%.*10^(-3);

% from time to frequence domain
[ frequencyMatrixB3 ] = FourierTransform( matrixB3 );
% Study on frequencies
[ deltaB3,alphaB3, betaB3,gammaB3] = FrequencyStudy( matrixB3,frequencyMatrixB3 );

% [ denoisedMatrixB3 ] = denoisingSignal( matrixB3 );
% % from time to frequence domain
% [ frequencyMatrixB3,DenoisedFrequencyMatrixB3 ] = FourierTransform( matrixB3,denoisedMatrixB3 );
% % Study on frequencies
% [ deltaB3,betaB3,gammaB3,alphaB3 ] = FrequencyStudy( matrixB3,frequencyMatrixB3 );

% %% Load Condition B4
% [tableB41,tableB42,tableB43,tableB44] = loadConditionB4();
% matrixB4 = [tableB41,tableB42,tableB43,tableB44];   % size(matrixA1)
% matrixB4 = matrixB4'; %.*10^(-3); %10x500000
% 
% % figure,plot(ad1_13*10)
% % from time to frequence domain
% [ frequencyMatrixB4 ] = FourierTransform( matrixB4 );
% % Study on frequencies
% [ deltaB4,alphaB4,betaB4,gammaB4] = FrequencyStudy( matrixB4,frequencyMatrixB4 );
% 
% % [ denoisedMatrixA1 ] = denoisingSignal( matrixA1 );
% % % from time to frequence domain
% % [ frequencyMatrixA1,DenoisedFrequencyMatrixA1 ] = FourierTransform( matrixA1,denoisedMatrixA1 );
% % % Study on frequencies
% % [ deltaA1,betaA1,gammaA1,alphaA1 ] = FrequencyStudy( matrixA1,frequencyMatrixA1 );


%% test
%
Fs = 100000;            % Sampling frequency                    
% T = 1/Fs;            % Sampling period       
L = size(matrixA1,2);% Length of signal
% t = (0:L-1)*T;       % Time vector
f = (0:L/2-1)*Fs/L; 


% 
% ratesA1 = countRates(frequencyMatrixA1,matrixA1);
% ratesA2 = countRates(frequencyMatrixA2,matrixA2);
% ratesA3 = countRates(frequencyMatrixA3,matrixA3);
ratesB1 = countRates(frequencyMatrixB1,matrixB1);
ratesB2 = countRates(frequencyMatrixB2,matrixB2);
ratesB3 = countRates(frequencyMatrixB3,matrixB3);
ratesB4 = countRates(frequencyMatrixB4,matrixB3);

% x4 = ratesB1;
% figure;
% bar(x4)
% % xlabel('delta','alpha','beta','gamma','Fontsize',18)
% ylabel('mean of rates B1','Fontsize',18)
% title('Mean of rates','Fontsize',18)

% means = [ratesA1;ratesA2;ratesA3;ratesB1;ratesB2;ratesB3];meanA1 = mean(ratesA1,1);

% meanA1 = mean(ratesA1,1);
% meanA2 = mean(ratesA2,1);
% meanA3 = mean(ratesA3,1);
meanB1 = mean(ratesB1,1);
meanB2 = mean(ratesB2,1);
meanB3 = mean(ratesB3,1);
%meanB4 = mean(ratesB4,1);

means = [meanB1;meanB2;meanB3]; %[meanA1;meanA2;meanA3]; %;meanB1;meanB2;meanB3];
x0 = means;
figure;
bar(x0)
% xlabel('delta','alpha','beta','gamma','Fontsize',18)
ylabel('means of rates ','Fontsize',18)
title('Mean of all rates Condition B','Fontsize',18)
axis ([0 4 0 40])
disp (meanB1, meanB2, meanB3)