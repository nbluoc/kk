function [rates,matrix] = countRates(frequencyMatrix,signals)
% this function counts which is the signal rate of each oscillation in relation to
% the whole signal.

Fs = 100000;           % Sampling frequency                    
% T = 1/Fs;            % Sampling period       
L = size(signals,2);   % Length of signal
% t = (0:L-1)*T;       % Time vector
f = (0:L/2-1)*Fs/L; 

delta = [];
theta = [];
alpha = [];
beta = [];
gamma = [];
highgamma = [];

matrix = zeros(size(signals,1),9); %12 features
for i=1:size(signals,1)
    signal = frequencyMatrix(i,:);
    pointer1 = 1;   
    pointer2 = 1;
    pointer3 = 1;
    pointer4 = 1;
    pointer5 = 1;
    pointer6 = 1;
    D = [];
    P = [];
    B = [];
    G = [];
    O = [];
    I = [];

    for j=1:length(f)
       if f(j) >= 1+1 && f(j) <= 4+1 % delta oscillations  1-4
            D(pointer1) = signal(j); % energeia tou simatos
            pointer1 = pointer1 + 1;
        elseif f(j) >=4+1 && f(j) <= 7+1 % 4-7 Hz theta
            P(pointer2) = signal(j);
            pointer2 = pointer2 + 1;    
        elseif f(j) >=8 && f(j) <= 12 % 8-12 Hz alpha
            B(pointer3) = signal(j);
            pointer3 = pointer3 + 1;
        elseif f(j) >= 13+1 && f(j) <= 30+1 % beta oscillations
            G(pointer4) = signal(j);
            pointer4 = pointer4 + 1;
        elseif f(j) > 30+1 && f(j) <= 80+1 % gamma oscillations
            O(pointer5) = signal(j);
            pointer5 = pointer5 + 1;
        elseif f(j) > 80+1 && f(j) <= 150+1 % high gamma oscillations
            I(pointer6) = signal(j);
            pointer6 = pointer6 + 1;
        end
    end
    delta(i) = (sum(D)/sum(signal))*100;
    theta(i) = (sum(P)/sum(signal))*100;
    alpha(i) = (sum(B)/sum(signal))*100;
    beta(i) = (sum(G)/sum(signal))*100;
    gamma(i) = (sum(O)/sum(signal))*100;
    highgamma(i) = (sum(I)/sum(signal))*100;
     
    %[rangePSDelta,maxPSDelta,maxFreqD]= findRangePowerSpectrum(D,f,signal,f(f>=2&f<=5)); %"findRangePowerSpectrum" :i synartisi ayti mas ftiaxnei ta features pou tha xrisimopoiithoun sto clustering
    %[rangePSTheta,maxPSTheta,maxFreqP]= findRangePowerSpectrum(P,f,signal,f(f>=5&f<=8));
    %[rangePSAlpha,maxPSAlpha,maxFreqB]= findRangePowerSpectrum(B,f,signal,f(f>=8&f<=12));
    %[rangePSBeta,maxPSBeta,maxFreqG]= findRangePowerSpectrum(G,f,signal,f(f>=14&f<=31));
    %[rangePSGamma,maxPSGamma,maxFreqO]= findRangePowerSpectrum(O,f,signal,f(f>31&f<=81));
    %[rangePSHighgamma,maxPSHighgamma,maxFreqI]= findRangePowerSpectrum(I,f,signal,f(f>81&f<=151));
    
    % isws k signal na ttsekarw
%     matrix(i,:) = [(sum(D)-mean(signal))./std(signal),maxFreqD,(maxPSDelta-mean(signal))./std(signal),(rangePSDelta-mean(signal))./std(signal),(sum(B)-mean(signal))./std(signal),maxFreqB,(maxPSBeta-mean(signal))./std(signal),(rangePSBeta-mean(signal))./std(signal),(sum(G)-mean(signal))./std(signal),maxFreqG,(maxPSGamma-mean(signal))./std(signal),(rangePSGamma-mean(signal))./std(signal)];
%     newD = normalization(D,f(f>=2&f<=5),signal);
%     newB = normalization(B,f(f>=14&f<=31),signal);
%     newG = normalization(G,f(f>31&f<=71),signal);

%matrix(i,:) = [sum(D),maxPSDelta,rangePSDelta,sum(P),maxPSTheta,rangePSTheta,sum(B),maxPSAlpha,rangePSAlpha,sum(G),maxPSBeta,rangePSBeta,sum(O),maxPSGamma,rangePSGamma,sum(I),maxPSHighgamma,rangePSHighgamma];

%     matrix(i,:) = [sum(D),maxFreqD-1,maxPSDelta,rangePSDelta,sum(B),maxFreqB-1,maxPSBeta,rangePSBeta,sum(G),maxFreqG-1,maxPSGamma,rangePSGamma];
%     matrixMyNormalization(i,:) = [sum(newD),maxFreqD-1,(maxPSDelta-mean(D))./std(D),rangePSDelta,sum(newB),maxFreqB-1,(maxPSBeta-mean(B))./std(B),rangePSBeta,sum(newG),maxFreqG-1,(maxPSGamma-mean(G))./std(G),rangePSGamma];
    
%     matrixMyNormalization(i,:) = [(sum(D)-mean(D))./std(D),maxFreqD-1,(maxPSDelta-mean(D))./std(D),(rangePSDelta-mean(D))./std(D),(sum(B)-mean(B))./std(B),maxFreqB-1,(maxPSBeta-mean(B))./std(B),(rangePSBeta-mean(B))./std(B),(sum(G)-mean(G))./std(G),maxFreqG-1,(maxPSGamma-mean(G))./std(G),(rangePSGamma-mean(G))./std(G)];
end
rates = [delta',theta',alpha',beta',gamma',highgamma'];

