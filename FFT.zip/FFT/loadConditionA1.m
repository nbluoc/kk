function [tableA11,tableA12,tableA13,tableA14] = loadConditionA1() 
% tableA11,tableA12,tableA13,tableA14,tableA15,tableA16
% kanw load ta dedomena

A=importdata('/Users/katerinakalemaki1/Documents/Field recordings/Dataset_katerinakalemaki_rac gamma oscillations/Condition A1/tableA11.dat');
tableA11 = A.data;

B=importdata('/Users/katerinakalemaki1/Documents/Field recordings/Dataset_katerinakalemaki_rac gamma oscillations/Condition A1/tableA12.dat');
tableA12 = B.data;

C=importdata('/Users/katerinakalemaki1/Documents/Field recordings/Dataset_katerinakalemaki_rac gamma oscillations/Condition A1/tableA13.dat');
tableA13 = C.data;
% 
D=importdata('/Users/katerinakalemaki1/Documents/Field recordings/Dataset_katerinakalemaki_rac gamma oscillations/Condition A1/tableA14.dat');
tableA14 = D.data;

% E=importdata('/Users/katerinakalemaki1/Documents/Field recordings/Dataset_katerinakalemaki_rac gamma oscillations/Condition A1/tableA15.dat');
% tableA15 = E.data;
% 
% F=importdata('/Users/katerinakalemaki1/Documents/Field recordings/Dataset_katerinakalemaki_rac gamma oscillations/Condition A1/tableA16.dat');
% tableA16 = F.data;

end

