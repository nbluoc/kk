function [ delta,theta,alpha,beta,gamma,highgamma] = FrequencyStudy( matrixA1,frequencyMatrixA1 )

Fs = 100000;            % Sampling frequency                    
% T = 1/Fs;            % Sampling period       
L = size(matrixA1,2);% Length of signal
% t = (0:L-1)*T;       % Time vector
f = (0:L/2-1)*Fs/L; %based on Nyquist
delta = [];
theta = [];
alpha = [];
beta = [];
gamma = [];
highgamma = [];

for i=1:250  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%1:10
    signal = frequencyMatrixA1(i,:);   
    pointer1 = 1;   
    pointer2 = 1;
    pointer3 = 1;
    pointer4 = 1;
    pointer5 = 1;
    pointer6 = 1;
    D = [];
    P = [];
    B = [];
    G = [];
    O = [];
    I = [];
    for j=1:length(f)
       if f(j) >= 1+1 && f(j) <= 4+1 % delta oscillations  
            D(pointer1) = signal(j); % energeia tou simatos
            pointer1 = pointer1 + 1;
        elseif f(j) >=4+1 && f(j) <= 7+1 % 4-7 Hz theta
            P(pointer2) = signal(j);
            pointer2 = pointer2 + 1;    
        elseif f(j) >=8 && f(j) <= 12 % 8-12 Hz alpha
            B(pointer3) = signal(j);
            pointer3 = pointer3 + 1;
        elseif f(j) >= 13+1 && f(j) <= 30+1 % beta oscillations
            G(pointer4) = signal(j);
            pointer4 = pointer4 + 1;
        elseif f(j) > 30+1 && f(j) <= 80+1 % gamma oscillations
            O(pointer5) = signal(j);
            pointer5 = pointer5 + 1;
       elseif f(j) > 80+1 && f(j) <= 150+1 % high gamma oscillations
            I(pointer6) = signal(j);
            pointer6 = pointer6 + 1;
        end
    end
    
    delta(i,:) = D;
    theta(i,:) = P;
    alpha(i,:) = B;
    beta(i,:) = G;
    gamma(i,:) = O;
    highgamma(i,:) = I;
    
end
    
end

% % % a.	Delta: 0.5-4 Hz
% % % b.	Theta: 4-12 Hz
% % % c.	Alpha: 8-13 Hz
% % % d.	Beta: 13-30 Hz
% % % e.	Gamma: 30-80 Hz
% % % f.	HighGamma: 80-150 Hz

